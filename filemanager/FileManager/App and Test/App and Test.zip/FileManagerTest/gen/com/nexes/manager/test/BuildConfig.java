/** Automatically generated file. DO NOT MODIFY */
package com.nexes.manager.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}